# Contributing Guidelines

Thank you for your interest in contributing!

## How to Contribute

1. Fork the repository
2. Create a new branch
3. Submit a pull request with a clear description
4. Ensure all tests pass and code is formatted